More information about preparing the video file for your SD card can be
found at these pages:

https://community.arm.com/groups/embedded/blog/2014/05/23/led-video-panel-at-maker-faire-2014

https://forum.pjrc.com/threads/25588-OctoWS2811-flicker?p=47485&viewfull=1#post47485
