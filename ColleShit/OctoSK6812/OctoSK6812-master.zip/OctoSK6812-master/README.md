OctoSK6812
==========

WARNING: this code has not been tested very thoroughly. Examples may not work, and may reference the old library. File an issue, with proposed fixed and I can make changes.


This is a port of Paul Stoffregen's OctoWS2811 Library to use SK6812 24 bit RGB and 32 bit RGBW LEDs.

This uses changes made by Mackenzie Hauck nocduro.ca that can be seen on hackaday:
https://hackaday.io/project/11850-led-light-rod/log/39905-modifying-octows2811-to-work-with-rgbw-led-strips

And combines it with the updated OctoWS811 code that supports Teensy LC as well as Teensy 3.5 3.6


Control thousands of SK6812 LEDs at video refresh speeds

http://www.pjrc.com/teensy/td_libs_OctoWS2811.html

https://www.youtube.com/watch?v=M5XQLvFPcBM
